//
//  AppDelegate.h
//  CatPad for Mac
//
//  Created by のんのん on 2022/08/14.
//

#import <Cocoa/Cocoa.h>

