//
//  AppDelegate.h
//  LINE MASHER 2 for Mac
//
//  Created by のんのん on 2023/01/31.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

