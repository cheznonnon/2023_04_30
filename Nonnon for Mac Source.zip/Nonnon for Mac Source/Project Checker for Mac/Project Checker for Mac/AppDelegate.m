//
//  AppDelegate.m
//  Project Checker for Mac
//
//  Created by のんのん on 2022/07/06.
//

#import "AppDelegate.h"


#include "../../nonnon/mac/n_txtbox.c"
#include "../../nonnon/mac/n_textfield.c"

#include "../../nonnon/mac/_mac.c"

#include "../../nonnon/neutral/dir.c"
#include "../../nonnon/neutral/filer.c"
#include "../../nonnon/neutral/txt.c"

#include "./engine.c"




@interface AppDelegate ()

@property (weak) IBOutlet NonnonTxtbox *n_list;

@property (weak) IBOutlet NSButton *n_button_reverse;
@property (weak) IBOutlet NSButton *n_button_go;

@property (weak) IBOutlet NonnonTextField *n_text_fr;
@property (weak) IBOutlet NonnonTextField *n_text_to;

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NSMenuItem *menu;

@property n_txt n_txt;

@end




@implementation AppDelegate {

	BOOL         finder_onoff;
	n_posix_bool complete_mode_onoff;

	int          click_phase;
	u32          click_msec;

	BOOL         debug_onoff;

}


@synthesize n_txt;


- (instancetype)init
{
	self = [super init];
	if ( self )
	{
		n_txt_zero( &n_txt ); n_txt_new( &n_txt );

		finder_onoff = FALSE;


		click_phase = 0;
		click_msec  = 0;


		debug_onoff = FALSE;
		//debug_onoff = TRUE;

		if ( debug_onoff )
		{
			int i = 0;
			n_posix_loop
			{
				n_posix_char str[ 100 ]; n_posix_sprintf_literal( str, "Test %d", i );
				n_txt_set( &n_txt, i, str );
				i++;
				if ( i >= 200 ) { break; }
			}
		}

	}
	
	return self;
}


- (void) n_list_txt_set:(n_posix_char*)str
{
	n_txt_free( &n_txt ); n_txt_new( &n_txt );
	n_txt_set( &n_txt, 0, str );

	[_n_list NonnonTxtboxReset];
	[_n_list display];
}


- (IBAction)n_button_reverse_pressed:(id)sender {

	NSString *tmp = [[_n_text_fr stringValue] copy];
	[_n_text_fr setStringValue:[_n_text_to stringValue]];
	[_n_text_to setStringValue:tmp];

}

- (IBAction)n_button_go:(id)sender {

	NSString *f = [_n_text_fr stringValue];
	NSString *t = [_n_text_to stringValue];

	if ( ( [f length] == 0 )||( [t length] == 0 ) )
	{
		[self n_list_txt_set:"Please Check"];
		finder_onoff = FALSE;
		return;
	}


	NSFileManager *fm = [NSFileManager defaultManager];

	BOOL is_dir_f;
	BOOL exists_f = [fm fileExistsAtPath:f isDirectory:&is_dir_f];

	BOOL is_dir_t;
	BOOL exists_t = [fm fileExistsAtPath:t isDirectory:&is_dir_t];

	if ( ( exists_f == FALSE )||( exists_t == FALSE ) )
	{
		[self n_list_txt_set:"Please Check"];
		finder_onoff = FALSE;
		return;
	}
	
	if ( is_dir_f != is_dir_t )
	{
		[self n_list_txt_set:"Please Check"];
		finder_onoff = FALSE;
		return;
	}
	
	if ( is_dir_f )
	{
//NSLog( @"Folders" );

		n_posix_char *str_f = n_mac_nsstring2str( f );
		n_posix_char *str_t = n_mac_nsstring2str( t );

		n_txt_free( &n_txt ); n_txt_new( &n_txt );
		n_pc_go_folder( _n_list, &n_txt, str_f, str_t, complete_mode_onoff, n_posix_true );
		n_pc_sort( &n_txt );

		[_n_list NonnonTxtboxReset];
		[_n_list display];

		finder_onoff = TRUE;

		n_string_free( str_f );
		n_string_free( str_t );

//n_txt_save( &txt, "ret.txt" );

	} else {

		BOOL is_same = [fm contentsEqualAtPath:f andPath:t];
//NSLog( @"is_same : %d", is_same );

		if ( is_same )
		{

			[self n_list_txt_set:"Same Binary"];

		} else {

			[self n_list_txt_set:"Different Binary"];


			n_posix_char *str_f = n_mac_nsstring2str( f );
			n_posix_char *str_t = n_mac_nsstring2str( t );

			n_posix_bool ret = n_posix_false;

			n_type_int diff_line = -1;

			n_txt txt_f; n_txt_zero( &txt_f ); ret |= n_txt_load( &txt_f, str_f );
			n_txt txt_t; n_txt_zero( &txt_t ); ret |= n_txt_load( &txt_t, str_t );

			if ( ret )
			{
//NSLog( @"n_txt_load()" );
				n_txt_free( &txt_f );
				n_txt_free( &txt_t );

				n_string_free( str_f );
				n_string_free( str_t );

				return;
			}

			if (
				( txt_f.newline == N_TXT_NEWLINE_BINARY )
				||
				( txt_t.newline == N_TXT_NEWLINE_BINARY )
			)
			{
//NSLog( @"N_TXT_NEWLINE_BINARY" );
				n_txt_free( &txt_f );
				n_txt_free( &txt_t );

				n_string_free( str_f );
				n_string_free( str_t );

				return;
			}

			n_type_int i = 0;
			n_posix_loop
			{
				if ( ( i >= txt_f.sy )&&( i >= txt_t.sy ) ) { break; }

				if ( i >= txt_f.sy ) { diff_line = i; break; }
				if ( i >= txt_t.sy ) { diff_line = i; break; }

				if ( n_string_is_same( n_txt_get( &txt_f, i ), n_txt_get( &txt_t, i ) ) )
				{
					//
				} else {
					diff_line = i;
					break;
				}

				i++;
			}


			if ( diff_line != -1 )
			{
				n_posix_char str_line[ N_STRING_INT2STR_CCH_MAX ]; n_string_int2str( str_line, 1 + diff_line );

				n_posix_char str[ 100 ];
				n_posix_sprintf_literal( str, "Line #%s", str_line );
//NSLog( @"%s", str );

				n_txt_add( &n_txt, 1, str );

				[_n_list display];
			}

			n_txt_free( &txt_f );
			n_txt_free( &txt_t );

			n_string_free( str_f );
			n_string_free( str_t );

		}

		finder_onoff = FALSE;
	}

}




- (void)rightMouseDown:(NSEvent *)theEvent
{

	[_n_list mouseDown:theEvent];

}

- (void)rightMouseUp:(NSEvent *)theEvent
{

	BOOL double_click_onoff = FALSE;

	if ( click_phase == 0 )
	{
		click_phase = 1;
		click_msec  = n_posix_tickcount() + 500; // [!] : same as Win32
	} else
	if ( click_phase == 1 )
	{
		if ( click_msec >= n_posix_tickcount() )
		{
			double_click_onoff = TRUE;
			click_phase = 0;
		} else {
			click_msec  = n_posix_tickcount() + 500; // [!] : same as Win32
		}
	}

	if ( debug_onoff )
	{

		if ( double_click_onoff )
		{
NSLog( @"Double-Clicked" );
			n_txt_del( &n_txt, _n_list.n_focus );
			[_n_list display];
		} else {
NSLog( @"Single-Clicked" );
		}

		return;
	}


	//double_click_onoff = ( ( [theEvent clickCount] % 3 ) == 2 );

	if ( double_click_onoff )
	{
//NSLog( @"double clicked" );


		if ( finder_onoff == FALSE ) { return; }


		n_type_int focus = _n_list.n_focus;
		if ( focus == -1 ) { return; }

		_n_list.n_focus = -1;

		n_posix_char *item = n_string_carboncopy( n_txt_get( &n_txt, focus ) );
		if ( 4 > n_posix_strlen( item ) ) { return; }


		[[NSCursor operationNotAllowedCursor] set];


		NSString *nsstr_f = [_n_text_fr stringValue];
		NSString *nsstr_t = [_n_text_to stringValue];
	
		n_posix_char *f = n_mac_nsstring2str( nsstr_f );
		n_posix_char *t = n_mac_nsstring2str( nsstr_t );

 
		// [!] : don't use n_string_path_name()
		//
		//	this will be relative path

		n_posix_char *name = n_string_path_carboncopy( item );

		int mode = 0;
		if ( item[ 0 ] == '!' ) { mode = 1; }
		if ( item[ 0 ] == '?' ) { mode = 1; }
		if ( item[ 0 ] == '+' ) { mode = 2; }

		n_string_copy( &item[ 4 ], item );
		n_string_copy( &item[ n_posix_strlen( t ) ], name );

		n_string_free( item );


		n_posix_char *f2 = n_string_path_cat( f, name, NULL );
		n_posix_char *t2 = n_string_path_cat( t, name, NULL );

		n_string_path_free( f ); f = f2;
		n_string_path_free( t ); t = t2;


//NSLog( @"Mode %d", mode );
		if ( mode == 1 )
		{

			if ( n_posix_false == n_filer_merge( f, t ) )
			{
				n_txt_del( &n_txt, focus );
				[_n_list display];
			}

		} else
		if ( mode == 2 )
		{
			NSURL *url = [NSURL fileURLWithPath:n_mac_str2nsstring( t )];

			BOOL ret = [[NSFileManager defaultManager]
				 trashItemAtURL:url
			       resultingItemURL:nil
				          error:nil
			];

			if ( ret == YES )
			{
				n_txt_del( &n_txt, focus );
				[_n_list display];
			}
		}


		[[NSCursor arrowCursor] set];

	}

}




- (void)mouseUp:(NSEvent *)theEvent
{

	if ( ( [theEvent clickCount] % 3 ) == 2 )
	{
//NSLog( @"double clicked" ); return;

		if ( finder_onoff == FALSE ) { return; }


		n_type_int focus = _n_list.n_focus;

		n_posix_char *item = n_string_carboncopy( n_txt_get( &n_txt, focus ) );
		if ( 4 > n_posix_strlen( item ) ) { return; }


		NSString *nsstr_f = [_n_text_fr stringValue];
		NSString *nsstr_t = [_n_text_to stringValue];
	
		n_posix_char *f = n_mac_nsstring2str( nsstr_f );
		n_posix_char *t = n_mac_nsstring2str( nsstr_t );

 
		// [!] : don't use n_string_path_name()
		//
		//	this will be relative path

		n_posix_char *name = n_string_path_carboncopy( item );

		n_string_copy( &item[ 4 ], item );
		n_string_copy( &item[ n_posix_strlen( t ) ], name );

		n_string_free( item );


		n_posix_char *f2 = n_string_path_cat( f, name, NULL );
		n_posix_char *t2 = n_string_path_cat( t, name, NULL );

		n_string_path_free( f ); f = f2;
		n_string_path_free( t ); t = t2;

		if (
			( n_posix_false == n_posix_stat_is_exist( f ) )
			||
			( n_posix_stat_is_dir( f ) )
		)
		{
			n_posix_char *upper = n_string_path_upperfolder_new( f );
			n_string_path_free( f ); f = upper;
		}

		if (
			( n_posix_false == n_posix_stat_is_exist( t ) )
			||
			( n_posix_stat_is_dir( t ) )
		)
		{
			n_posix_char *upper = n_string_path_upperfolder_new( t );
			n_string_path_free( t ); t = upper;
		}

		n_mac_finder_call( n_mac_str2nsstring( f ) );
		n_mac_finder_call( n_mac_str2nsstring( t ) );

	}

}


- (IBAction)n_complete_mode_onoff:(id)sender {

	NSControlStateValue s = [_menu state];
	if ( s == NSControlStateValueOff )
	{
		[_menu setState:NSControlStateValueOn];
		complete_mode_onoff = n_posix_true;
	} else {
		[_menu setState:NSControlStateValueOff];
		complete_mode_onoff = n_posix_false;
	}

}


- (void)awakeFromNib
{

	_n_list.delegate_option     = N_MAC_TXTBOX_DELEGATE_MOUSEUP_LEFT | N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_RIGHT | N_MAC_TXTBOX_DELEGATE_MOUSEUP_RIGHT;
	_n_list.delegate            = self;
	_n_list.n_mode              = N_MAC_TXTBOX_MODE_LISTBOX;
	_n_list.n_txt_data          = &n_txt;
	_n_list.n_option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_ONEBASED_INDEX;

	_n_list.n_listbox_no_selection_onoff = TRUE;

	NSFont *font = n_mac_stdfont();
	[_n_list NonnonTxtboxFontChange:font];

	[_n_list NonnonTxtboxReset];


	// [!] : macOS 12 Monterey needs this
	[_window setFrameAutosaveName:@"Nonnon.ProjectChecker"];

	// [!] : Xib constraints : misbehaves when size is small
	NSSize nssize = NSMakeSize( 480, 360 );
	[_window setContentMinSize:nssize];


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];
}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (IBAction)n_pc_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"project checker" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}


@end
