// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




static n_bmp      n_paint_preview_bmp;
static n_type_gfx n_paint_preview_default_sx = -1;
static n_type_gfx n_paint_preview_default_sy = -1;




// internal
void
n_paint_preview_cache_exit( n_paint *paint )
{

	n_bmp_free( &n_paint_preview_bmp );


	return;
}

// internal
void
n_paint_preview_cache_init( n_paint *paint, NSWindow *window, NSView *view )
{

	n_bmp_zero( &n_paint_preview_bmp );


	if ( paint->layer_onoff )
	{
		n_paint_layer_save_as_one( paint, &n_paint_preview_bmp );
	} else {
		n_bmp_carboncopy( paint->pen_bmp_data, &n_paint_preview_bmp );
		n_paint_grabber_composition( paint->pen_bmp_grab, &n_paint_preview_bmp, n_posix_true, n_posix_true );
	}

	n_bmp_flush_mirror( &n_paint_preview_bmp, N_BMP_MIRROR_UPSIDE_DOWN );


	CGFloat desktop_sx, desktop_sy;
	n_mac_desktop_size( &desktop_sx, &desktop_sy );

	n_type_gfx minim = n_posix_min_n_type_gfx( desktop_sx, desktop_sy );
	n_type_gfx cs    = (n_type_gfx) ( (n_type_real) minim * 0.9 );


	n_type_gfx bmpsx = N_BMP_SX( paint->pen_bmp_data );
	n_type_gfx bmpsy = N_BMP_SY( paint->pen_bmp_data );

	if ( ( cs > bmpsx )||( cs > bmpsy ) )
	{
		n_bmp_resizer( &n_paint_preview_bmp, cs, cs, n_bmp_black, N_BMP_RESIZER_CENTER );
	}


	n_type_real ratio_x = 1.0;
	n_type_real ratio_y = 1.0;

	if ( ( cs < bmpsx )||( cs < bmpsy ) )
	{
		ratio_x = ratio_y = (n_type_real) cs / n_posix_min_n_type_real( bmpsx, bmpsy );
	}

	n_bmp_resampler( &n_paint_preview_bmp, ratio_x, ratio_y );


	n_type_gfx csx = N_BMP_SX( &n_paint_preview_bmp );
	n_type_gfx csy = N_BMP_SY( &n_paint_preview_bmp );

	[window setContentSize:NSMakeSize( csx,csy )];
	[view setFrame:NSMakeRect( 0,0,csx,csy )];

	n_paint_preview_default_sx = csx;
	n_paint_preview_default_sy = csy;


	[view display];


	return;
}




@interface NonnonPaintPreview : NSView

@property (nonatomic,assign) id delegate;

@end


@implementation NonnonPaintPreview


@synthesize delegate;




- (instancetype)initWithCoder:(NSCoder *)coder
{
	self = [super initWithCoder:coder];

	if ( self )
	{
		n_bmp_zero( &n_paint_preview_bmp );
	}

	return self;
}

-(void) drawRect:(NSRect) rect
{

/*
	n_win_hwndprintf_literal
	(
		hwnd,
		"Preview : X %dpx (%d%%) : Y %dpx (%d%%)",
		tsx - n_paint_preview_default_sx,
		(int) trunc( (n_type_real) tsx / n_paint_preview_default_sx * 100 ),
		tsy - n_paint_preview_default_sy,
		(int) trunc( (n_type_real) tsy / n_paint_preview_default_sy * 100 )
	);
*/

	n_mac_image_nbmp_direct_draw( &n_paint_preview_bmp, &rect, NO );

}




- (BOOL)acceptsFirstResponder
{
//NSLog(@"acceptsFirstResponder");
	return YES;
}

- (BOOL)becomeFirstResponder
{
//NSLog(@"becomeFirstResponder");
        return YES;
}

- (void) keyDown : (NSEvent*) event
{
//NSLog( @"Key Code = %d", event.keyCode );

	switch( event.keyCode ) {

	case N_MAC_KEYCODE_NUMBER_1: 

		[self.delegate keyDown:event];

	break;

	} // switch

}


- (void) mouseUp:(NSEvent *)theEvent
{
//NSLog(@"mouseUp");

	if ( [theEvent clickCount] == 2 )
	{

		[self.delegate mouseUp:theEvent];

	}

}


@end
