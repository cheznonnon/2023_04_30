//
//  AppDelegate.m
//  Nyaagle for Mac
//
//  Created by のんのん on 2023/02/10.
//

#import "AppDelegate.h"



#include "../../nonnon/mac/n_textfield.c"
#include "../../nonnon/mac/n_txtbox.c"


#include "engine.c"




NSWindow *n_nyaagle_window = NULL;

@interface NyaagleImageView: NSImageView
@end

@implementation NyaagleImageView

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	[n_nyaagle_window performWindowDragWithEvent:theEvent];

}

@end




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NonnonTextField *n_path;
@property (weak) IBOutlet NonnonTxtbox    *n_search;
@property (weak) IBOutlet NonnonTxtbox    *n_list;
@property (weak) IBOutlet NSMenuItem      *n_menu_file_name_only;

@property n_txt n_txt_data_search;
@property n_txt n_txt_data_list;

@end




@implementation AppDelegate {

	n_bmp search_icon;

}




@synthesize n_txt_data_search;
@synthesize n_txt_data_list;




- (void) NyaagleGo
{

	[[NSCursor operationNotAllowedCursor] set];


	n_posix_char *path  = n_mac_nsstring2str( [_n_path stringValue] );
	n_posix_char *query = n_txt_get( _n_search.n_txt_data, 0 );

	// [Needed] : sandbox off

	if ( n_posix_stat_is_file( path ) )
	{
		n_posix_char *upper = n_string_path_upperfolder_new( path );
		n_string_free( path );
		path = upper;
	}

	NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
	[pasteboard clearContents];
	[pasteboard writeObjects:@[ n_mac_str2nsstring( query ) ]];



	n_posix_bool prv_search = n_nyaagle_is_text_search;

	if ( _n_search.n_is_shift_pressed )
	{
		n_nyaagle_is_text_search = n_posix_false;
	}


	if ( n_txt_data_list.sy == 1 )
	{
		n_txt_utf8_new( &n_txt_data_list );
		[_n_list NonnonTxtboxReset];
		[_n_list display];

		n_nyaagle_directory( &n_txt_data_list, path, query );
	} else {
		n_nyaagle_ntxt( &n_txt_data_list, query );
	}

	if ( n_posix_false == n_txt_is_empty( &n_txt_data_list ) )
	{
		_n_list.n_line_offset = n_posix_strlen( path );
	}


	n_nyaagle_is_text_search = prv_search;


	[_n_list display];

	n_string_free( path );


	[[NSCursor arrowCursor] set];


	return;
}

- (void) NonnonTxtbox_delegate_edited:(NonnonTxtbox*)txtbox onoff:(BOOL)onoff
{

	if ( txtbox == _n_search )
	{

		if ( _n_search.n_is_enter_pressed )
		{
			[self NyaagleGo];
		}

	}

}

- (void) NonnonTxtbox_delegate_F3:(NonnonTxtbox*)txtbox
{
//NSLog( @"NonnonTxtbox_delegate_F3" );

	[self NyaagleGo];

}




- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	if ( [theEvent clickCount] == 2 )
	{
		n_posix_char *path  = n_txt_get( &n_txt_data_list, _n_list.n_focus );
		NSString     *nsstr = n_mac_str2nsstring( path );

		if ( n_posix_stat_is_dir( path ) )
		{
			n_mac_finder_call( nsstr );
		} else {
			[[NSWorkspace sharedWorkspace] openFile:nsstr];
		}
	}

}




- (void)awakeFromNib
{

	NSFont *font = n_mac_stdfont();


	_n_path.n_folder_only = TRUE;


	n_txt_zero( &n_txt_data_search );
	n_txt_utf8_new( &n_txt_data_search );

	_n_search.delegate_option     = N_MAC_TXTBOX_DELEGATE_EDITED | N_MAC_TXTBOX_DELEGATE_F3;
	_n_search.delegate            = self;
	_n_search.n_txt_data          = &n_txt_data_search;
	_n_search.n_mode              = N_MAC_TXTBOX_MODE_FINDBOX;
	_n_search.n_focus             = 0;
	_n_search.n_option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_NONE;

	[_n_search NonnonTxtboxFontChange:font];

	{
		n_bmp_zero( &search_icon );
		n_mac_image_rc_load_bmp( @"search_64", &search_icon );

		n_bmp_flush_mirror( &search_icon, N_BMP_MIRROR_UPSIDE_DOWN );

		_n_search.n_findbox_bmp_icon = &search_icon;
	}

	[_n_search NonnonTxtboxReset];


	n_txt_zero( &n_txt_data_list );
	n_txt_utf8_new( &n_txt_data_list );

	_n_list.delegate_option     = N_MAC_TXTBOX_DELEGATE_MOUSEDOWN_LEFT;
	_n_list.delegate            = self;
	_n_list.n_mode              = N_MAC_TXTBOX_MODE_LISTBOX;
	_n_list.n_txt_data          = &n_txt_data_list;
	_n_list.n_option_linenumber = N_MAC_TXTBOX_DRAW_LINENUMBER_ONEBASED_INDEX;

	_n_list.n_listbox_no_selection_onoff = TRUE;

	[_n_list NonnonTxtboxFontChange:font];

	[_n_list NonnonTxtboxReset];


	// [!] : Xib constraints : misbehaves when size is small
	NSSize nssize = NSMakeSize( 512, 512 );
	[_window setContentMinSize:nssize];


	n_nyaagle_window = _window;


	[self themeChanged:nil];

	[NSDistributedNotificationCenter.defaultCenter
	      addObserver: self
		 selector: @selector( themeChanged: )
		     name: @"AppleInterfaceThemeChangedNotification"
		   object: nil
	];


	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];
}

-(void)themeChanged:(NSNotification *) notification
{
//NSLog( @"themeChanged" );

	if ( n_mac_is_darkmode() )
	{
		self.window.backgroundColor = [NSColor windowBackgroundColor];
	} else {
		self.window.backgroundColor = [NSColor whiteColor];
	}

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}




- (IBAction)n_menu_file_name_only:(id)sender {

	NSControlStateValue s = [_n_menu_file_name_only state];
	if ( s == NSControlStateValueOff )
	{
		[_n_menu_file_name_only setState:NSControlStateValueOn];
		n_nyaagle_is_text_search = n_posix_false;
	} else {
		[_n_menu_file_name_only setState:NSControlStateValueOff];
		n_nyaagle_is_text_search = n_posix_true;
	}

}

- (IBAction)n_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"nyaagle" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}




- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}


@end
