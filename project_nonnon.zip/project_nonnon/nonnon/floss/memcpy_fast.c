// Nonnon FLOSS
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_FLOSS_MEMCPY
#define _H_NONNON_FLOSS_MEMCPY




#ifdef _MSC_VER


#include "../win32/sysinfo/version.c"


#include "./memcpy_fast/avx.h"
#include "./memcpy_fast/sse.h"




int
n_memcpy_avx_is_supported( void )
{

	// [x] : below code is buggy

	return n_sysinfo_version_8_or_later();

/*
	// [!] : AVX On/Off Checker : I've found this on StackOverflow

	int avxSupported = 0;


	int cpuInfo[ 4 ]; __cpuid( cpuInfo, 1 );

	int osUsesXSAVE_XRSTORE = cpuInfo[ 2 ] & ( 1 << 27 ) || 0;
	int cpuAVXSuport        = cpuInfo[ 2 ] & ( 1 << 28 ) || 0;

	if ( osUsesXSAVE_XRSTORE && cpuAVXSuport )
	{
		unsigned long long xcrFeatureMask = _xgetbv( _XCR_XFEATURE_ENABLED_MASK );

		avxSupported = ( ( xcrFeatureMask & 0x6 ) == 0x6 );
	}


	return avxSupported;
*/
}

inline void
n_memcpy_fast( void *dst, const void *src, size_t count )
{

	static int avx_onoff = -1;

	if ( avx_onoff == -1 )
	{
		avx_onoff = n_memcpy_avx_is_supported();
	}

	if ( avx_onoff )
	{
		memcpy_fast_avx( dst, src, count );
	} else {
		memcpy_fast_sse( dst, src, count );
	}


	return;
}




#else  // #ifdef _MSC_VER




#ifndef __APPLE__
inline
#endif // #ifndef __APPLE__
void
n_memcpy_fast( void *dst, const void *src, size_t count )
{

	// [!] : a little faster : I've found this on StackOverflow

	u8 *dst8 = (u8*) dst;
	u8 *src8 = (u8*) src;

	if ( count & 1 )
	{
		dst8[ 0 ] = src8[ 0 ];

		dst8 += 1;
		src8 += 1;
	}

	// [!] : this code only improves performance
	//
	//	u32 or u64 are not faster, a little slower

	count /= 2;

	while( count-- )
	{
		dst8[ 0 ] = src8[ 0 ];
		dst8[ 1 ] = src8[ 1 ];

		dst8 += 2;
		src8 += 2;
	}


	return;
}




#endif // #ifdef _MSC_VER




#endif // _H_NONNON_FLOSS_MEMCPY


