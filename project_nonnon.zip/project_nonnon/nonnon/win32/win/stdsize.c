// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_STDSIZE
#define _H_NONNON_WIN32_WIN_STDSIZE




#include "../registry.c"

#include "./font.c"
#include "./gui.c"
#include "./fluent_ui.c"
#include "./rect.c"
#include "./stdfont.c"
#include "./style.c"




#define n_win_stdsize_icon_large( sx, sy ) n_win_stdsize_icon( sx, sy, n_posix_true  )
#define n_win_stdsize_icon_small( sx, sy ) n_win_stdsize_icon( sx, sy, n_posix_false )

void
n_win_stdsize_icon( n_type_gfx *sx, n_type_gfx *sy, n_posix_bool is_large )
{

	if ( is_large )
	{
		if ( sx != NULL ) { (*sx) = GetSystemMetrics( SM_CXICON   ); }
		if ( sy != NULL ) { (*sy) = GetSystemMetrics( SM_CYICON   ); }
	} else {
		if ( sx != NULL ) { (*sx) = GetSystemMetrics( SM_CXSMICON ); }
		if ( sy != NULL ) { (*sy) = GetSystemMetrics( SM_CYSMICON ); }
	}


	return;
}

n_type_gfx
n_win_stdsize_check( HWND hwnd )
{

	// [ Mechanism ] : no standard logic available
	//
	//	100%  96 13
	//	125% 120 16 : 13 + 3
	//	150% 144 18 : 13 + 5
	//	175% 168 20 : 13 + 7
	//	200% 192 24 : 13 + 9
	//	225% 216 28 : 13 + 15
	//	250% 240 30 : 13 + 17
	//	300% 288 36 : 13 + 23

	n_type_gfx ret = 13;
	n_type_gfx dpi = n_win_dpi( hwnd );

	if ( dpi != 96 )
	{
		ret = (n_type_gfx) ( (n_type_real) ret * ( (n_type_real) dpi / 96 ) );
	}

	if ( n_win_fluent_ui_onoff ) { ret += (n_type_gfx) ( (n_type_real) dpi / 96 ) * 2; }


	return ret;
}

n_type_gfx
n_win_stdsize_radio( HWND hwnd )
{

	n_type_gfx ret = 13;
	n_type_gfx dpi = n_win_dpi( hwnd );

	if ( dpi != 96 )
	{
		ret = (n_type_gfx) ( (n_type_real) ret * ( (n_type_real) dpi / 96 ) );
	}

	if ( n_win_fluent_ui_onoff ) { ret += (n_type_gfx) ( (n_type_real) dpi / 96 ) * 2; }


	return ret;
}

void
n_win_stdsize_text( HWND hwnd, const n_posix_char *str, n_type_gfx *sx, n_type_gfx *sy )
{

	// [Mechanism]
	//
	//	WM_GETFONT returns real hfont, not copy of it
	//	WM_GETFONT returns NULL when system font
	//	so don't n_win_font_exit() with it


	// [Needed] : multi-thread

	HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_win_stdsize_text()" );


	HDC   hdc = GetDC( hwnd );
	HFONT pf  = SelectObject( hdc, n_win_font_get( hwnd ) );

	SIZE size;
	GetTextExtentPoint32( hdc, str, (int) n_posix_strlen( str ), &size );

	SelectObject( hdc, pf );
	ReleaseDC( hwnd, hdc );


	hmutex = n_win_mutex_exit( hmutex );


	if ( sx != NULL ) { (*sx) = size.cx; }
	if ( sy != NULL ) { (*sy) = size.cy; }


	return;
}

n_type_gfx
n_win_stdsize_caret( HWND hwnd )
{

	// [!] : IME uses hard-coded 2px in all version


	// [!] : Win9x/NT4 : "CaretWidth" is not exist and Edit draws a 2px caret

	DWORD caret_size = 2;

	n_posix_char *subkey  = n_posix_literal( "Control Panel\\Desktop" );
	n_posix_char *section = n_posix_literal( "CaretWidth" );

	n_registry_read( HKEY_CURRENT_USER, subkey, section, &caret_size, sizeof( DWORD ) );


	// [!] : Windows doesn't touch when high-DPI settings has high value

	int dpi = n_win_dpi( hwnd );

	if ( ( caret_size == 1 )&&( dpi != 96 ) )
	{
		caret_size *= (DWORD) dpi / 96;
	}


	return caret_size;
}

void
n_win_stdsize( HWND hwnd, n_type_gfx *control, n_type_gfx *icon, n_type_gfx *margin )
{

	// [!] : XP or later only available : SM_CYFOCUSBORDER

	//n_type_gfx fx = GetSystemMetrics( SM_CXFOCUSBORDER );
	//n_type_gfx fy = GetSystemMetrics( SM_CYFOCUSBORDER );
	//n_type_gfx mx = GetSystemMetrics( SM_CXEDGE );
	//n_type_gfx my = GetSystemMetrics( SM_CYEDGE );
	n_type_gfx cx = GetSystemMetrics( SM_CXVSCROLL );
	n_type_gfx cy = GetSystemMetrics( SM_CYHSCROLL );
	n_type_gfx ix = GetSystemMetrics( SM_CXICON );
	n_type_gfx iy = GetSystemMetrics( SM_CYICON );

	n_type_real scale = n_win_scale( hwnd );

	//n_type_gfx  b = n_posix_max_n_type_gfx( bx, by );
	//n_type_gfx  f = n_posix_max_n_type_gfx( fx, fy );
	n_type_gfx  m = (n_type_gfx) ( (n_type_real) scale * 3 );
	n_type_gfx  c = n_posix_max_n_type_gfx( cx, cy );
	n_type_gfx  i = n_posix_max_n_type_gfx( ix, iy );

/*
	{

		// [!] : use combobox height which is automatically determined

		// [x] : heavy

		HWND h = NULL;
		n_win_gui( hwnd, N_WIN_GUI_COMBO, N_STRING_EMPTY, &h );

		if ( h != NULL )
		{

			n_win_stdfont_init( &h, 1 );

			RECT r = n_win_rect_size( h );

			n_win_stdfont_exit( &h, 1 );

			DestroyWindow( h );

			c = n_posix_max_n_type_gfx( c, r.bottom );

		}

//n_win_hwndprintf_literal( hwnd, "%d : %d", c, (int) r.bottom );

	}
*/

	{

		// [!] : combobox height equivalent : classic/uxtheme compatible


		// [Needed] : multi-thread

		HANDLE hmutex = n_win_mutex_init_and_wait_literal( NULL, "n_win_stdsize()" );


		HDC   hdc = GetDC( hwnd );
		HFONT pf  = SelectObject( hdc, n_win_stdfont_hfont() );

		SIZE size;
		GetTextExtentPoint32( hdc, N_STRING_SPACE, (int) n_posix_strlen( N_STRING_SPACE ), &size );

		n_win_font_exit( SelectObject( hdc, pf ) );
		ReleaseDC( hwnd, hdc );


		hmutex = n_win_mutex_exit( hmutex );


		n_type_gfx ctl = size.cy;

		n_type_gfx add = (n_type_gfx) trunc( (n_type_real) GetSystemMetrics( SM_CYEDGE ) * 2 * 2 * scale );
//n_posix_debug_literal( " %f ", scale );

		if ( scale != 1.0 )
		{
			add += (n_type_gfx) ceil( scale * 2 );
		}

		c = n_posix_max_n_type_gfx( c, ctl + add );

	}

//n_posix_debug_literal( " %d %d ", c, m );

	m = n_posix_max_n_type_gfx( m, ( c / 8 ) - 1 );
	i = n_posix_max_n_type_gfx( i, c + ( c / 2 ) );


	if (
		( n_win_style_is_classic() )
		||
		( n_sysinfo_version_xp() )
	)
	{
		c += m;
	}


	// [!] : for alignment : for win_smallbutton.c

	// [!] : backward compatibility : after calculation of "m", "i"

	c += ( c % 2 );


	if ( control != NULL ) { (*control) = c + ( m * 2 ); }
	if ( icon    != NULL ) { (*icon)    = i + ( m * 2 ); }
	if ( margin  != NULL ) { (*margin)  = m            ; }


	return;
}


#endif // _H_NONNON_WIN32_WIN_STDSIZE

