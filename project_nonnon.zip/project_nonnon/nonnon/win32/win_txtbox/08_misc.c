// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_fade_go( n_win_txtbox *p, n_bmp_fade *fade )
{

	u32 color;
	if ( fade->color_fg == n_bmp_white )
	{
		color = n_bmp_black;
	} else {
		color = n_bmp_white;
	}

	fade->stop = n_posix_true;

	n_bmp_fade_go( fade, color );


	return;
}

n_posix_char*
n_win_txtbox_eol_string_get( n_win_txtbox *p )
{

	n_posix_char *eol_str = N_STRING_EMPTY;


	if ( n_string_is_empty( p->eol_mark ) ) { return eol_str; }


	if ( n_string_is_same_literal( "auto", p->eol_mark ) )
	{
#ifdef UNICODE
		eol_str = n_posix_literal( "\x21a9" );
#else  // #ifdef UNICODE
		eol_str = n_posix_literal( "<" );
#endif // #ifdef UNICODE
	} else {
		eol_str = p->eol_mark;
	}


	return eol_str;
}

void
n_win_txtbox_previous( n_win_txtbox *p )
{

	p->prv_oneline_scroll = p->scroll_pxl_tabbed_x;

	p->prv_sel_x  = p->select_cch_x;
	p->prv_sel_y  = p->select_cch_y;
	p->prv_sel_sx = p->select_cch_sx;
	p->prv_sel_sy = p->select_cch_sy;
	p->prv_txt_sy = p->txt.sy;
	p->prv_drag   = p->shift_dragging;


	return;
}

void
n_win_txtbox_grayed( n_win_txtbox *p, n_posix_bool onoff )
{

	if ( p == NULL ) { return; }


	p->is_grayed = onoff;

	if ( onoff )
	{
		p->grayed_onoff = n_posix_true;

		p->color_back_noselect = p->color_back_disabled;
		p->color_back_selected = p->color_sel_focus_off;
	} else {
		p->color_back_noselect = p->color_back__enabled;
	}

	 n_win_txtbox_refresh( p, N_WIN_TXTBOX_GRAYED );


	return;
}

void
n_win_txtbox_scale_set( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->scale_real = n_win_scale( p->hwnd );
	p->scale      = (n_type_gfx) ceil( p->scale_real );


	return;
}

n_posix_char*
n_win_txtbox_txt_get( n_win_txtbox *p, n_type_int y )
{

	n_posix_char *str = n_txt_get( &p->txt, y );

	if ( p->style_option & N_WIN_TXTBOX_OPTION_LISTBOX_EFFECTS )
	{
		str = &str[ 3 ];
	}


	return str;
}

// internal
n_type_gfx
n_win_txtbox_horizontal_centering( n_win_txtbox *p )
{

	n_type_gfx ret = 0;

	if (
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER )
	)
	{
		n_posix_char *text = n_win_txtbox_txt_get( p, 0 );

		SIZE size = n_win_txtbox_size_text( p, text );
		if ( p->canvas_real_pxl_sx > size.cx )
		{
			ret = ( p->canvas_real_pxl_sx - size.cx ) / 2;
		}
	}


	return ret;
}


