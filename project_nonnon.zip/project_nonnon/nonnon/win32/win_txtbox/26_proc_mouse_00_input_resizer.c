// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_input_resizer_cursor_add( HWND hwnd, n_posix_char *idc )
{

	n_win_cursor_add( hwnd, idc );
	//n_win_cursor_add( NULL, idc );


	return;
}

void
n_win_txtbox_input_resizer_location( n_win_txtbox *p, n_type_gfx *x, n_type_gfx *y, n_type_gfx *sx, n_type_gfx *sy )
{

	n_win_location( p->hwnd, x,y,sx,sy );


	if ( x != NULL ) { (*x) += p->maclike_offset; }


	return;
}

n_posix_bool
n_win_txtbox_input_resizer_onoff( n_win_txtbox *p, n_type_gfx cursor_x, n_type_gfx cursor_y )
{

	n_posix_bool ret = n_posix_false;


	n_type_gfx m; n_win_stdsize( p->hwnd, NULL, NULL, &m );
	n_type_gfx threshold = m * 2;


	n_type_gfx x,y,sx,sy;
	n_win_txtbox_input_resizer_location( p, &x,&y,&sx,&sy );

	if (
		( threshold >= abs( cursor_x - x ) )
		&&
		( ( y <= cursor_y )&&( ( y + sy ) >= cursor_y ) )
	)
	{
		ret = n_posix_true;
	}


	return ret;
}

n_posix_bool
n_win_txtbox_input_resizer_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	switch( msg ) {


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == 0 ) { break; }

		if ( wparam == p->input_resizer_timer_id )
		{
//break;
			if ( p->input_resizer_onoff == n_posix_false ) { break; }


			n_type_gfx cursor_x, cursor_y;
			n_win_cursor_position_relative( n_win_hwnd_toplevel( hwnd ), &cursor_x, &cursor_y );

			if ( p->input_resizer_cursor_x_prv == -1 ) { p->input_resizer_cursor_x_prv = cursor_x; }


			n_type_gfx x,y,sx,sy;
			n_win_txtbox_input_resizer_location( p, &x,&y,&sx,&sy );
//n_win_hwndprintf_literal( hwnd, " %d %d : %d %d %d %d ", cursor_x,cursor_y, x, y, sx, sy );


			n_type_gfx ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );
			n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );

			sx = n_posix_minmax( ctl * 4, w.csx - p->input_resizer_icon_sx - ( m * 2 ), w.csx - cursor_x );
			sy = ( ctl *  1 );
			 x = ( w.csx - m ) - sx;
			 y = ( ico - ctl ) / 2;

			n_type_gfx threshold = m * 2;
			if ( threshold >= abs( p->input_resizer_cursor_x_prv - cursor_x ) ) { break; }

			n_win_txtbox_move( p, x,y, sx,sy, n_posix_false );


			InvalidateRect( GetParent( p->hwnd ), NULL, n_posix_false );


			p->input_resizer_cursor_x_prv = sx;

		}

	break;


	case WM_MOUSEMOVE :
	{
//n_win_hwndprintf_literal( hwnd, " WM_MOUSEMOVE " );

		n_type_gfx cursor_x, cursor_y;
		n_win_cursor_position_relative( n_win_hwnd_toplevel( hwnd ), &cursor_x, &cursor_y );

		if ( p->input_resizer_onoff )
		{

			n_win_txtbox_input_resizer_cursor_add( hwnd, IDC_SIZEWE );

		} else {

			// [Needed] : Win95 needs this position

			if ( n_win_txtbox_input_resizer_onoff( p, cursor_x, cursor_y ) )
			{
				n_win_txtbox_input_resizer_cursor_add( hwnd, IDC_SIZEWE );
			} else {
				n_win_txtbox_input_resizer_cursor_add( hwnd, IDC_ARROW  );

				n_win_timer_exit( hwnd, p->input_resizer_timer_id );
			}

		}

	}
	break;


	case WM_LBUTTONDBLCLK :
	{

		p->input_resizer_onoff = n_posix_false;


		n_type_gfx cursor_x, cursor_y;
		n_win_cursor_position_relative( n_win_hwnd_toplevel( hwnd ), &cursor_x, &cursor_y );

		if ( n_win_txtbox_input_resizer_onoff( p, cursor_x, cursor_y ) )
		{
			n_win_txtbox_input_resizer_cursor_add( hwnd, IDC_SIZEWE );
		} else {
			n_win_txtbox_input_resizer_cursor_add( hwnd, IDC_ARROW  );

			break;
		}


		n_type_gfx x,y,sx,sy;
		n_win_txtbox_input_resizer_location( p, &x,&y,&sx,&sy );

		n_type_gfx ctl,ico,m; n_win_stdsize( hwnd, &ctl, &ico, &m );
		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CALCONLY );

		sx = n_posix_min_n_type_gfx( ( ctl * 12 ), w.csx - ( m * 2 ) );
		sy = ( ctl *  1 );
		 x = ( w.csx - m ) - sx;
		 y = ( ico - ctl ) / 2;

		n_win_txtbox_move( p, x,y, sx,sy, n_posix_false );


		InvalidateRect( GetParent( p->hwnd ), NULL, n_posix_false );


		n_win_txtbox_input_resizer_location( p, &x,NULL, NULL,NULL );

		POINT pt = { x - m, cursor_y };

		ClientToScreen( hwnd, &pt );
		SetCursorPos( pt.x, pt.y );


		return n_posix_true;
	}
	break;


	case WM_LBUTTONDOWN :
	{

		n_type_gfx cursor_x, cursor_y;
		n_win_cursor_position_relative( n_win_hwnd_toplevel( hwnd ), &cursor_x, &cursor_y );

		if ( n_win_txtbox_input_resizer_onoff( p, cursor_x, cursor_y ) )
		{
			p->input_resizer_onoff = n_posix_true;

			n_win_txtbox_input_resizer_cursor_add( hwnd, IDC_SIZEWE );

			if ( p->input_resizer_timer_id == 0 ) { p->input_resizer_timer_id = n_win_timer_id_get(); }
			n_win_timer_init( hwnd, p->input_resizer_timer_id, 1 );
		}

		SetCapture( hwnd );

	}
	break;

	case WM_LBUTTONUP :
	{

		p->input_resizer_onoff = n_posix_false;

		n_type_gfx cursor_x, cursor_y;
		n_win_cursor_position_relative( n_win_hwnd_toplevel( hwnd ), &cursor_x, &cursor_y );

		if ( n_win_txtbox_input_resizer_onoff( p, cursor_x, cursor_y ) )
		{
			n_win_txtbox_input_resizer_cursor_add( hwnd, IDC_SIZEWE );
		} else {
			n_win_txtbox_input_resizer_cursor_add( hwnd, IDC_ARROW  );
		}

		ReleaseCapture();

	}
	break;


	} // switch


	return n_posix_false;
}


